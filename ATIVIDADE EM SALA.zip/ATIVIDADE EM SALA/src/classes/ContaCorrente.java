package classes;

public class ContaCorrente extends Conta {

    @Override
    public void atualiza(double taxa) {
        double saldoAtual = getSaldo();
        double novoSaldo = saldoAtual + (saldoAtual * taxa * 2); // Atualiza-se com o dobro da taxa
        setSaldo(novoSaldo);
    }
}
